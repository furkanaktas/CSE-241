/* 
 * File:   requiredIncs.h
 * Author: furkan
 *
 * Created on 9 Kasım 2016 Çarşamba, 09:21
*/

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "CPU.h"
#include "CPUProgram.h"
#include "Memory.h"
#include "Computer.h"


#endif /* REQUIREDINCS_H */
