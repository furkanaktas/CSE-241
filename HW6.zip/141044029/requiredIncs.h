/* 
 * File:   requiredIncs.h
 * Author: furkan
 *
 * Created on 27 Kasım 2016 Pazar, 20:25
*/

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include "CPU.h"
#include "CPUProgram.h"
#include "Memory.h"
#include "Computer.h"
#include "CPUProgramDyn.h"
using namespace dynamic;

#endif /* REQUIREDINCS_H */
