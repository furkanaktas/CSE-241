/* 
 * File:   requiredIncs.h
 * Author: furkan
 *
 * Created on 26 Aralık 2016 Pazartesi, 16:20
 */

#ifndef REQUIREDINCS_H
#define REQUIREDINCS_H

#include <cstdlib>
#include <string>
#include <iostream>

#include "Bigram.h"
#include "BigramMap.h"
#include "BigramMap.cpp"
#include "BigramDyn.h"
#include "BigramDyn.cpp"

using namespace std;

#endif /* REQUIREDINCS_H */


